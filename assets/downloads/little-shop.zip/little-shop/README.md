# Little Shop — complete local learning project

Angular 22 + Python / FastAPI / SQLAlchemy / SQLite.

Start with **projects.html → shop → Step 01** in the academy. The Sinhala workbook is `docs/COURSE-WORKBOOK.md`. The final implementation is a reference: use the numbered lessons to build your own copy in a separate practice folder.

## 1. Extract and configure

Extract the ZIP while keeping `frontend/`, `backend/`, `compose.yaml` and `.env.example` together. In VS Code use File → Open Folder on `little-shop/`.

Copy `.env.example` to `.env` in that root and replace **both** passwords with different, long ASCII values (12+ characters). Use simple values without spaces, quotes, `#`, `$` or `:` for this Basic-auth learning example.

- macOS/Linux terminal: `cp .env.example .env`
- Windows PowerShell: `Copy-Item .env.example .env`
- Windows CMD: `copy .env.example .env`

The `.env` is ignored by Git and Docker builds. These are local environment accounts, not a registration or production identity system. Manager operations are enforced by the API. Catalog reads are public. Credentials stay in tab memory and are sent using Basic auth; HTTPS is required for remote traffic.

## 2. Easiest full-stack run: Docker

Install Docker Desktop (Windows/macOS) or Docker Engine + Compose (Linux), and start it. From the project root:

```bash
docker compose config --quiet
docker compose up --build -d
docker compose ps
```

Open **http://localhost:8088**. The frontend reverse-proxies `/api` to the backend, so no separate browser CORS setup is necessary. Enter the account values from your `.env`. First builds need internet and can take several minutes.

Add products, complete a transaction using the limited account, then enter manager credentials and Load history. Stock decreases and the saved receipt uses server prices.

For this shop, customer name and delivery address are required. This app records orders; real payment processing, delivery integrations and customer registration are extensions.

```bash
docker compose logs --tail=80 api
docker compose down
docker compose up -d
```

Records survive container recreation in the named `app-data` volume. `docker compose down -v` permanently removes that data; do not use it for routine stopping. Frontend port 8088 is bound to localhost for this local project. Use one course stack at a time or change its host port.

## 3. Native backend run (without Docker)

Install **Python 3.12+**. In terminal 1, from `backend/`:

macOS/Linux:

```bash
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements.lock.txt
.venv/bin/python -m pytest -q
.venv/bin/python -m uvicorn app.main:app --reload --port 8000
```

Windows PowerShell or CMD (activation is not required):

```powershell
py -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.lock.txt
.\.venv\Scripts\python.exe -m pytest -q
.\.venv\Scripts\python.exe -m uvicorn app.main:app --reload --port 8000
```

API: http://127.0.0.1:8000/api/health. Interactive API docs: http://127.0.0.1:8000/docs. The API reads project-root `.env` automatically. Local data is `backend/build-lab.db`; keep the file to preserve records. The reference migration SQL is SQLite-specific. Do not point it at PostgreSQL without reviewing/porting migrations and concurrency tests.


Leave terminal 1 running. Stop with Ctrl+C.

## 4. Native Angular run

Install a compatible Node.js: **24.15.0+ in the 24.x line**, or another version in the Angular 22 official compatibility matrix. Check `node --version` and `npm --version`. In terminal 2, from `frontend/`:

```bash
npm ci
npm start
```

Open **http://localhost:4200**. The included proxy targets port 8000. Restart `npm start` if you change the proxy. Edit `src/app/app.html` to see live UI updates. Credentials entered in the app are applied to subsequent requests; entering them alone does not verify the account.

```bash
npm run build
```

Build output: `frontend/dist/build-lab/browser/`. Never use the development server as your production server.

## 5. Follow one request

`app.html` click → `app.ts` state and form logic → `api.ts` HTTP service → app/main.py → app/service.py → SQLAlchemy + versioned SQLite migrations → transaction commit → response receipt → inventory refresh.

Model names/JSON contracts are in `frontend/src/app/models.ts` and `API-CONTRACT.md`. The database stores money in integer minor units; Rs.450.00 is 45000. UI totals are estimates. The server calculates authoritative prices and stores immutable unit-price snapshots. Product creation/edit API endpoints are manager-only; their administrative UI is an extension.

## 6. Tests and CI

Run `python -m pytest -q` using the backend virtual environment. Tests cover valid transactions, identity/permissions, malformed input, unknown products and rollback. A failing second item rolls back the first stock decrement and the order header. Run `npm run build` in frontend/ for template/type checking. Also exercise the real browser UI: empty cart, error, valid save, stock refresh, history and responsive layout.

The GitHub Actions workflow tests the backend and builds Angular and both images. Create your own GitHub repository, review `.gitignore` and staged changes, then push your branch and open a pull request. The workflow does not automatically publish images or deploy a host.

## 7. Extend toward production

Read `docs/release-runbook.md`. Review identity/session design, HTTPS, production database/migrations, durable idempotency, rate/body limits, backup/restore, audit access, logs/metrics, rollback and dependency policies. These local capstones do not claim production readiness. A retried successful POST can create another order; implement a durable idempotency key before accepting real checkout traffic.

## Troubleshooting

- `node`/`py`/`java` not found: install the runtime, check PATH, and open a new terminal.
- `ENOENT package.json`: change into `frontend/`, not the ZIP root.
- API import error: run Uvicorn from `backend/`, with its virtual environment interpreter.
- 401: use the current `.env` credentials; restart the backend after editing its environment.
- 403: the account has no permission for the action.
- 409: inventory or request state changed; refresh and review quantities/status.
- 502/network error: verify backend health, proxy port and `docker compose ps`.
- Data disappeared: check current working directory/database path and volume name; do not delete the DB to fix schema changes.

Official references: [Angular versions](https://angular.dev/reference/versions), [FastAPI](https://fastapi.tiangolo.com/tutorial/), [Spring](https://docs.spring.io/spring-boot/system-requirements.html), [Docker Compose](https://docs.docker.com/compose/gettingstarted/).
