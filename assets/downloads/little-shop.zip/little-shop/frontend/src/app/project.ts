export const PROJECT: {kind: string; title: string; action: string} = {"kind": "shop", "title": "Little Shop", "action": "Place order"};
