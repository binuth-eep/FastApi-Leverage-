# API contract

- GET /api/health → 200 {"status":"ok"} (public liveness).
- GET /api/ready → 200 after a DB query (public readiness).
- GET /api/products → 200 direct array of {id,name,price_minor,stock} (public).
- POST /api/products → 201 product. Manager only. Body {name,price_minor,stock}.
- PATCH /api/products/{id} → 200 product. Manager only. Body {name,price_minor}. Stock changes are business operations, not this patch.
- POST /api/orders → 201 saved transaction. Authenticated cashier/customer or manager.
- GET /api/orders → latest 100 saved transactions, manager only.


Use Basic authentication for protected routes. 

Request: `{"items":[{"product_id":1,"quantity":2}],"customer":"Amali","address":"12 Temple Road, Kandy"}`.

Constraints: 1–50 unique product rows; integer IDs > 0; integer quantities 1–1000; product price_minor 0–100000000; stock 0–1000000. Extra request fields are rejected. Money is an integer in minor currency units. Customer/address strings are trimmed and limited to 80/300 characters in the commerce API.

Response: `{"id":1,"status":"COMPLETED","total_minor":90000,"created_at":"ISO-8601 UTC timestamp","items":[{"product_id":1,"quantity":2,"unit_price_minor":45000}]}`.

Invalid shape → 422; missing/bad identity → 401; missing permission → 403; missing resource → 404; insufficient stock/already-approved/capacity conflict → 409. Domain errors use {"detail":"message"}. Framework validation errors may have a structured detail array in FastAPI. Never display raw server tracebacks.

Checkout atomically decrements stock with a conditional UPDATE and saves the order and price snapshots in the same transaction. Any item failure rolls back all changes. Successful POST retries are not deduplicated in this local reference.
