# Release and recovery runbook template

This local project needs a reviewed production configuration before exposure.

## Evidence

- Scope / acceptance tests:
- Reviewed commit SHA / current image tags / previous image tags:
- CI test/build evidence:
- Production identity provider/session policy / HTTPS termination:
- Durable idempotency and concurrent transaction test results:
- Database engine/version / migration versions / upgrade evidence:
- Secret store / rotation / request limits / CORS or CSRF policy:
- Backup destination / encryption / retention / successful restore evidence:
- RPO (acceptable data loss) / RTO (recovery time target):
- Monitoring / redacted logs / readiness / alert owner:
- 320px–1440px, keyboard and reduced-motion UI checks:

## Release sequence

1. Test the exact reviewed commit, build and tag immutable images.
2. Restore a backup in staging and apply the migration once. Test upgrade, not only fresh install.
3. Configure production secrets and HTTPS on the host. Keep the database private.
4. Back up production, deploy compatible images, check readiness, and run a sandbox business transaction.
5. Check unauthorized access, stock/approval consistency and monitoring before opening traffic.

## Rollback

1. Stop new writes if integrity is uncertain. Record the incident timestamp and current versions.
2. Deploy the previously verified image tag only if the current schema is backward compatible.
3. If data recovery is necessary, rehearse and execute the database-specific restore plan; an image rollback does not undo a destructive migration.
4. Verify counts, business invariants, health and one sandbox transaction before resuming traffic.
5. Document cause, affected records and the regression test added.

## Owner and incident commands

Fill in real hostnames, backup/restore commands, deployment commands, owner and alert contacts here. Do not copy placeholder commands to production.
