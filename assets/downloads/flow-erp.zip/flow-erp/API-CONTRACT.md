# API contract

- GET /api/health → 200 {"status":"ok"} (public liveness).
- GET /api/ready → 200 after a DB query (public readiness).
- GET /api/products → 200 direct array of {id,name,price_minor,stock} (public).
- POST /api/products → 201 product. Manager only. Body {name,price_minor,stock}.
- PATCH /api/products/{id} → 200 product. Manager only. Body {name,price_minor}. Stock changes are business operations, not this patch.
- POST /api/requests → 201 saved transaction. Authenticated staff or manager.
- GET /api/requests → latest 100 saved transactions, authenticated staff/manager.
- POST /api/requests/{id}/approve → 200 approved transaction. Manager only. Repeats return 409.

Use Basic authentication for protected routes. All write requests also require `X-Build-Lab: 1`. No cross-origin CORS policy is enabled; this custom header is part of the same-origin local API CSRF boundary.

Request: `{"items":[{"product_id":1,"quantity":2}]}`.

Constraints: 1–50 unique product rows; integer IDs > 0; integer quantities 1–1000; product price_minor 0–100000000; stock 0–1000000. Extra request fields are rejected. Money is an integer in minor currency units. Customer/address strings are trimmed and limited to 80/300 characters in the commerce API.

Response: `{"id":1,"status":"PENDING","total_minor":90000,"created_at":"ISO-8601 UTC timestamp","items":[{"product_id":1,"quantity":2,"unit_price_minor":45000}]}`.

Invalid shape → 400; missing/bad identity → 401; missing permission → 403; missing resource → 404; insufficient stock/already-approved/capacity conflict → 409. Domain errors use {"detail":"message"}. Framework validation errors may have a structured detail array in FastAPI. Never display raw server tracebacks.

Creating a purchase request does not change stock. Approval conditionally claims PENDING state and writes inventory and audit records in one transaction.
