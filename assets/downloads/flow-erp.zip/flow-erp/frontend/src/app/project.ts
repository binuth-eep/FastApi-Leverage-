export const PROJECT: {kind: string; title: string; action: string} = {"kind": "erp", "title": "Flow ERP", "action": "Create purchase request"};
